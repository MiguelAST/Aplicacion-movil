package com.example.supermercado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //metodo empleado
    public void empleado(View view){
        Intent txtempleado = new Intent(this, Empleado.class);
        startActivity(txtempleado);
    }

    //metodo producto
    public void producto(View view){
        Intent txtproducto = new Intent(this,Producto.class);
        startActivity(txtproducto);
    }

    //metodo Categoria
    public void categoria(View view){
        Intent txtcategoria = new Intent(this,Categoria.class);
        startActivity(txtcategoria);
    }

    //metodo proveedor
    public void proveedor(View view){
        Intent txtproveedor = new Intent(this,Proveedor.class);
        startActivity(txtproveedor);
    }

    //metodo supermercado
    public void supermercado(View view){
        Intent txtsupermercado = new Intent(this,Supermercado.class);
        startActivity(txtsupermercado);
    }

    //metodo supermercado
    public void ventas(View view){
        Intent txtventa  = new Intent(this,Ventas.class);
        startActivity(txtventa);
    }

}